-- conectar com --default-character-set=utf8




-- **********************************
-- fin_check_valores
-- **********************************

delimiter //


DROP PROCEDURE IF EXISTS `fin_check_valores`//


CREATE PROCEDURE `fin_check_valores`(
        IN `valor` DECIMAL(15,2),
        IN `descontos` DECIMAL(15,2),
        IN `acrescimos` DECIMAL(15,2),
        IN `valor_total` DECIMAL(15,2)
    )
    NOT DETERMINISTIC
    CONTAINS SQL
    SQL SECURITY DEFINER
    COMMENT ''
BEGIN
	
	DECLARE _msg VARCHAR(2000);
	
	SELECT COALESCE(valor, 0.0) INTO valor;
    SELECT COALESCE(descontos, 0.0) INTO descontos;
    SELECT COALESCE(acrescimos, 0.0) INTO acrescimos;
    SELECT COALESCE(valor_total, 0.0) INTO valor_total;
	
	
    

	IF ( (valor - descontos + acrescimos) != valor_total) THEN
		SELECT get_message(1005) INTO _msg;
	    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = _msg;
    END IF;

END//




-- **********************************
-- fin_check_dt_consolidado
-- **********************************


delimiter //


DROP PROCEDURE IF EXISTS `fin_check_dt_consolidado`//

CREATE PROCEDURE `fin_check_dt_consolidado`(
        IN `_carteira_id` BIGINT,
        IN `_dt_moviment` DATE,
        IN `_dt_vencto` DATE,
        IN `_dt_vencto_efetiva` DATE,
        IN `_dt_pagto` DATE,
        IN `_dt_estorno` DATE,
        IN `_dt_util` DATE
    )
    NOT DETERMINISTIC
    CONTAINS SQL
    SQL SECURITY DEFINER
    COMMENT ''
BEGIN
	DECLARE _dt_consolidado DATE;
	DECLARE _msg VARCHAR(2000);

    SELECT dt_consolidado INTO _dt_consolidado FROM fin_carteira WHERE id = _carteira_id;
    
    -- VERIFICAÇÕES DAS DATAS ...
	
	-- Dt Vencto Efetiva não pode ser anterior a Dt Vencto
    if _dt_vencto_efetiva < _dt_vencto THEN
		SELECT get_message(1000) INTO _msg;
    	SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = _msg;
    END IF;
    
    -- Dt Útil: ou é a Dt Vencto Efetiva ou é a Dt Pagto
    IF _dt_util != _dt_vencto_efetiva and _dt_util != _dt_pagto THEN
    	SELECT get_message(1001) INTO _msg;
		SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = _msg;
    END IF;
    
   
    -- Dt Vencto Efetiva não pode ser anterior a Dt Consolidado da Carteira
    IF _dt_vencto_efetiva <= _dt_consolidado THEN
    	SELECT CONCAT(get_message(1002), ' (' , date_format(_dt_consolidado, '%d/%m/%Y'), ')') INTO _msg;
    	SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = _msg;
    END IF;
    
	-- Dt Pagto não pode ser anterior a Dt Consolidado da Carteira
    IF _dt_pagto <= _dt_consolidado THEN
    	SELECT CONCAT(get_message(1003), ' (' , date_format(_dt_consolidado, '%d/%m/%Y'), ')') INTO _msg;
    	SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = _msg;
    END IF;
    
	-- Dt Estorno não pode ser anterior a Dt Consolidado da Carteira
    IF _dt_estorno <= _dt_consolidado THEN
    	SELECT CONCAT(get_message(1004), ' (' , date_format(_dt_consolidado, '%d/%m/%Y'), ')') INTO _msg;
    	SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = _msg;
    END IF;
   

END//





-- **********************************
-- fin_check_vinculante
-- **********************************


delimiter //

DROP PROCEDURE IF EXISTS `fin_check_vinculante`//

CREATE PROCEDURE `fin_check_vinculante`(
        IN `_cadeia_id` BIGINT
    )
    NOT DETERMINISTIC
    CONTAINS SQL
    SQL SECURITY DEFINER
    COMMENT ''
BEGIN

	DECLARE _msg VARCHAR(2000);

	DECLARE _vinculante BIT(1);
    
    SELECT vinculante FROM fin_cadeia WHERE id = _cadeia_id INTO _vinculante;
    
    IF (_vinculante = true) THEN
		SELECT get_message(1006) INTO _msg;
    	SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = _msg;	
    END IF;

END //

















-- **********************************
-- trg_bi_fin_movimentacao
-- **********************************



delimiter //

DROP TRIGGER IF EXISTS `trg_bi_fin_movimentacao` //

CREATE TRIGGER `trg_bi_fin_movimentacao` BEFORE INSERT ON `fin_movimentacao`
  FOR EACH ROW
BEGIN

	CALL fin_check_valores(NEW.valor, NEW.descontos, NEW.acrescimos, NEW.valor_total);

	CALL fin_check_dt_consolidado(NEW.carteira_id,
    							NEW.dt_moviment,
                                NEW.dt_vencto,
                                NEW.dt_vencto_efetiva,
                                NEW.dt_pagto,
                                NEW.dt_estorno,
                                NEW.dt_util);
	
END//




-- **********************************
-- trg_bu_fin_movimentacao
-- **********************************

delimiter //

DROP TRIGGER IF EXISTS `trg_bu_fin_movimentacao` //


CREATE TRIGGER `trg_bu_fin_movimentacao` BEFORE UPDATE ON `fin_movimentacao`
  FOR EACH ROW
BEGIN

	
    CALL fin_check_vinculante(OLD.cadeia_id);
    
    CALL fin_check_valores(NEW.valor, NEW.descontos, NEW.acrescimos, NEW.valor_total);
	

	CALL fin_check_dt_consolidado(NEW.carteira_id,
    							NEW.dt_moviment,
                                NEW.dt_vencto,
                                NEW.dt_vencto_efetiva,
                                NEW.dt_pagto,
                                NEW.dt_estorno,
                                NEW.dt_util);
        
END//






-- **********************************
-- trg_bd_fin_movimentacao
-- **********************************


delimiter //

DROP TRIGGER IF EXISTS `trg_bd_fin_movimentacao` //

CREATE TRIGGER `trg_bd_fin_movimentacao` BEFORE DELETE ON `fin_movimentacao`
  FOR EACH ROW
BEGIN

	CALL fin_check_dt_consolidado(OLD.carteira_id,
    							OLD.dt_moviment,
                                OLD.dt_vencto,
                                OLD.dt_vencto_efetiva,
                                OLD.dt_pagto,
                                OLD.dt_estorno,
                                OLD.dt_util);
	
END//





-- **********************************
-- trg_ad_fin_movimentacao
-- **********************************


delimiter //

DROP TRIGGER IF EXISTS `trg_ad_fin_movimentacao` //



CREATE TRIGGER `trg_ad_fin_movimentacao` AFTER DELETE ON `fin_movimentacao`
  FOR EACH ROW
BEGIN

	-- TRIGGER PARA IMPEDIR QUE EXISTAM CADEIAS SEM NENHUMA MOVIMENTAÇÃO
    
	DECLARE restantes INTEGER;
   		
	SELECT count(*) FROM fin_movimentacao WHERE cadeia_id = OLD.cadeia_id INTO restantes;
    
    IF (restantes < 1) THEN
    	DELETE FROM fin_cadeia WHERE id = OLD.cadeia_id;
    END IF;
    

END //








