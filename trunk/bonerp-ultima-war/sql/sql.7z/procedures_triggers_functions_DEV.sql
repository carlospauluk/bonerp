-- MySQL dump 10.13  Distrib 5.5.42, for Win64 (x86)
--
-- Host: localhost    Database: bonerp_dev
-- ------------------------------------------------------
-- Server version	5.5.42
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 */ /*!50003 TRIGGER `trg_bi_fin_movimentacao` BEFORE INSERT ON `fin_movimentacao`
  FOR EACH ROW
BEGIN

	CALL fin_check_valores(NEW.valor, NEW.descontos, NEW.acrescimos, NEW.valor_total);

	CALL fin_check_dt_consolidado(NEW.carteira_id,
    							NEW.dt_moviment,
                                NEW.dt_vencto,
                                NEW.dt_vencto_efetiva,
                                NEW.dt_pagto,
                                NEW.dt_estorno,
                                NEW.dt_util);
                                
	CALL `fin_check_cadeia_fechada`(NEW.cadeia_id);
	
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 */ /*!50003 TRIGGER `trg_bu_fin_movimentacao` BEFORE UPDATE ON `fin_movimentacao`
  FOR EACH ROW
BEGIN

	
    CALL fin_check_vinculante(OLD.cadeia_id);
    
    CALL fin_check_valores(NEW.valor, NEW.descontos, NEW.acrescimos, NEW.valor_total);
	

	CALL fin_check_dt_consolidado(NEW.carteira_id,
    							NEW.dt_moviment,
                                NEW.dt_vencto,
                                NEW.dt_vencto_efetiva,
                                NEW.dt_pagto,
                                NEW.dt_estorno,
                                NEW.dt_util);
        
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `trg_au_fin_movimentacao` AFTER UPDATE ON `fin_movimentacao`
  FOR EACH ROW
BEGIN

   	CALL `fin_check_restantes_cadeia`(OLD.cadeia_id);

END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 */ /*!50003 TRIGGER `trg_bd_fin_movimentacao` BEFORE DELETE ON `fin_movimentacao`
  FOR EACH ROW
BEGIN

	CALL fin_check_dt_consolidado(OLD.carteira_id,
    							OLD.dt_moviment,
                                OLD.dt_vencto,
                                OLD.dt_vencto_efetiva,
                                OLD.dt_pagto,
                                OLD.dt_estorno,
                                OLD.dt_util);
	
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 */ /*!50003 TRIGGER `trg_ad_fin_movimentacao` AFTER DELETE ON `fin_movimentacao`
  FOR EACH ROW
BEGIN
  
	CALL `fin_check_restantes_cadeia`(OLD.cadeia_id);
    
    CALL `fin_check_restantes_parcelamento`(OLD.parcelamento_id);
    


END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Dumping routines for database 'bonerp_dev'
--
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `get_message`(
        `_id` BIGINT
    ) RETURNS varchar(2000) CHARSET utf8 COLLATE utf8_swedish_ci
BEGIN
	
	DECLARE _msg VARCHAR(2000);

	SELECT msg FROM _msgs WHERE id = _id INTO _msg;

  RETURN _msg;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE  FUNCTION `is_id_in_ids`(
        `strIDs` VARCHAR(255),
        `_id` BIGINT
    ) RETURNS bit(1)
BEGIN

  DECLARE strLen    INT DEFAULT 0;
  DECLARE subStrLen INT DEFAULT 0;
  DECLARE subs		VARCHAR(255);

  IF strIDs IS NULL THEN
    SET strIDs = '';
  END IF;
  
  

  do_this:
    LOOP
      SET strLen = LENGTH(strIDs);
      SET subs = SUBSTRING_INDEX(strIDs, ',', 1);
      
      if ( CAST(subs AS UNSIGNED) = _id ) THEN
        
      	return(1);
      END IF;
      
      SET subStrLen = LENGTH(SUBSTRING_INDEX(strIDs, ',', 1));
      SET strIDs = MID(strIDs, subStrLen+2, strLen);
      
      
      
      IF strIDs = NULL or trim(strIds) = '' THEN
        LEAVE do_this;
      END IF;
      
  END LOOP do_this;
  
   
  return(0);
  
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `fin_check_cadeia_fechada`(
        IN `_cadeia_id` BIGINT
    )
BEGIN
	DECLARE _msg VARCHAR(2000);

	DECLARE _fechada BIT(1);
    
    SELECT fechada FROM fin_cadeia WHERE id = _cadeia_id INTO _fechada;
    
    IF (_fechada = true) THEN
		SELECT get_message(1007) INTO _msg;
    	SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = _msg;	
    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `fin_check_dt_consolidado`(
        IN `_carteira_id` BIGINT,
        IN `_dt_moviment` DATE,
        IN `_dt_vencto` DATE,
        IN `_dt_vencto_efetiva` DATE,
        IN `_dt_pagto` DATE,
        IN `_dt_estorno` DATE,
        IN `_dt_util` DATE
    )
BEGIN
	DECLARE _dt_consolidado DATE;
	DECLARE _msg VARCHAR(2000);

    SELECT dt_consolidado INTO _dt_consolidado FROM fin_carteira WHERE id = _carteira_id;
    
    
	
	
    if _dt_vencto_efetiva < _dt_vencto THEN
		SELECT get_message(1000) INTO _msg;
    	SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = _msg;
    END IF;
    
    
    IF _dt_util != _dt_vencto_efetiva and _dt_util != _dt_pagto THEN
    	SELECT get_message(1001) INTO _msg;
		SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = _msg;
    END IF;
    
   
    
    IF _dt_vencto_efetiva <= _dt_consolidado THEN
    	SELECT CONCAT(get_message(1002), ' (' , date_format(_dt_consolidado, '%d/%m/%Y'), ')') INTO _msg;
    	SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = _msg;
    END IF;
    
	
    IF _dt_pagto <= _dt_consolidado THEN
    	SELECT CONCAT(get_message(1003), ' (' , date_format(_dt_consolidado, '%d/%m/%Y'), ')') INTO _msg;
    	SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = _msg;
    END IF;
    
	
    IF _dt_estorno <= _dt_consolidado THEN
    	SELECT CONCAT(get_message(1004), ' (' , date_format(_dt_consolidado, '%d/%m/%Y'), ')') INTO _msg;
    	SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = _msg;
    END IF;
   

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `fin_check_restantes_cadeia`(
        IN `_cadeia_id` BIGINT
    )
BEGIN
	DECLARE restantes INTEGER;
    
    -- não posso chamar isto, o mysql não aceita delete dentro de trigger de delete.
    -- CALL fin_delete_vinculantes(OLD.cadeia_id);  
   		
	SELECT count(*) FROM fin_movimentacao WHERE cadeia_id = _cadeia_id INTO restantes;
    
    IF (restantes < 1) THEN
    	DELETE FROM fin_cadeia WHERE id = _cadeia_id;
    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `fin_check_restantes_parcelamento`(
        IN `_parcelamento_id` BIGINT
    )
BEGIN
	DECLARE restantes INTEGER;
    
 		
	SELECT count(*) FROM fin_movimentacao WHERE parcelamento_id = _parcelamento_id INTO restantes;
    
    IF (restantes < 1) THEN
    	DELETE FROM fin_parcelamento WHERE id = _parcelamento_id;
    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `fin_check_valores`(
        IN `valor` DECIMAL(15,2),
        IN `descontos` DECIMAL(15,2),
        IN `acrescimos` DECIMAL(15,2),
        IN `valor_total` DECIMAL(15,2)
    )
BEGIN
	
	DECLARE _msg VARCHAR(2000);
	
	SELECT COALESCE(valor, 0.0) INTO valor;
    SELECT COALESCE(descontos, 0.0) INTO descontos;
    SELECT COALESCE(acrescimos, 0.0) INTO acrescimos;
    SELECT COALESCE(valor_total, 0.0) INTO valor_total;
	
	
    

	IF ( (valor - descontos + acrescimos) != valor_total) THEN
		SELECT get_message(1005) INTO _msg;
	    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = _msg;
    END IF;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE  PROCEDURE `fin_check_vinculante`(
        IN `_cadeia_id` BIGINT
    )
BEGIN

	-- MSG: Não é possível atualizar uma movimentação vinculada.

	DECLARE _msg VARCHAR(2000);

	DECLARE _vinculante BIT(1);
    
    SELECT vinculante FROM fin_cadeia WHERE id = _cadeia_id INTO _vinculante;
    
    IF (false and _vinculante = true) THEN
		SELECT get_message(1006) INTO _msg;
    	SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = _msg;	
    END IF;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `fin_delete_vinculantes`(
        IN `_old_cadeia_id` BIGINT
    )
BEGIN

	DECLARE _vinculante BIT(1);
    
    SELECT vinculante FROM fin_cadeia WHERE id = _old_cadeia_id INTO _vinculante;
    
    IF (_vinculante = true) THEN
		DELETE FROM fin_movimentacao WHERE cadeia_id = _old_cadeia_id;
    END IF;


END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `fin_rp_planilha_parcelamento`(
        IN `_parcelamento_id` BIGINT
    )
BEGIN

	DECLARE ano_ini INT;
    DECLARE ano_fim INT;
    DECLARE mes_aux INT;
    
    DECLARE _dia_vencto INT;
    
    
    -- variáveis para insert na temporary table
    DECLARE _titulo VARCHAR(200);
    DECLARE _descricao VARCHAR(200);
    DECLARE _dt_vencto DATE;
    DECLARE _valor_prev DECIMAL(15,2);
    DECLARE _valor_realiz DECIMAL(15,2);
    
    DECLARE dt_ini_aux, dt_fim_aux DATE;
    
    DECLARE _status_aux VARCHAR(50);

	-- descobre o ano do primeiro vencto
    SELECT YEAR(dt_vencto), descricao, DAY(dt_vencto) FROM fin_movimentacao WHERE parcelamento_id = _parcelamento_id ORDER BY dt_vencto LIMIT 1 INTO ano_ini, _titulo, _dia_vencto;
    
    -- descobre o ano do último vencto
    SELECT YEAR(dt_vencto) FROM fin_movimentacao WHERE parcelamento_id = _parcelamento_id ORDER BY dt_vencto DESC LIMIT 1 INTO ano_fim;
       
    
    -- retornar
    -- titulo	descricao	dt_vencto	valor_prev	valor_realiz
    DROP TEMPORARY TABLE IF EXISTS _rp_planilha;
    CREATE TEMPORARY TABLE IF NOT EXISTS _rp_planilha (      
      ano INT,
      titulo VARCHAR(200),
      descricao VARCHAR(200),
      dt_vencto DATE,
      valor_prev DECIMAL(15,2),
      valor_realiz DECIMAL(15,2)
      ) DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci ENGINE=MEMORY;
    
    
    SET mes_aux = 1;
    
    
   
     
	-- percorre todos os meses (de janeiro a dezembro) de cada ano
    
    
    
    REPEAT
    
    	SET _valor_prev = NULL;
        SET _valor_realiz = NULL;
        SET _status_aux = NULL;
        SET _dt_vencto = NULL;
    
    	block1: begin
        
        	DECLARE CONTINUE HANDLER FOR NOT FOUND BEGIN END;
            
            SELECT 
            	dt_vencto, valor_total, status 
            FROM fin_movimentacao 
            	WHERE
                parcelamento_id = _parcelamento_id AND 
                dt_vencto >= STR_TO_DATE(CONCAT('1','-',mes_aux,'-',ano_ini),'%e-%c-%Y') AND
                dt_vencto < LAST_DAY( STR_TO_DATE(CONCAT('1','-',mes_aux,'-',ano_ini),'%e-%c-%Y') )
                INTO _dt_vencto, _valor_prev, _status_aux;
        
        end;
        
        if ifnull(_dt_vencto, true) then
        	SET _dt_vencto = STR_TO_DATE(CONCAT(_dia_vencto,'-',mes_aux,'-',ano_ini),'%e-%c-%Y');
        end if;
        
        SET _valor_realiz = null;
               
        if _status_aux = 'REALIZADA' then
            SET _valor_realiz = _valor_prev;
        end if;
            
        SET _descricao = CONCAT(_titulo,' - ',DATE_FORMAT(_dt_vencto,'%m/%Y'));
            
        INSERT INTO _rp_planilha VALUES(ano_ini,_titulo,_descricao,_dt_vencto,_valor_prev,_valor_realiz);
                
			
        if mes_aux = 12 then
            SET mes_aux = 0; -- 0 pois vai incrementar logo baixo
            SET ano_ini = ano_ini + 1;
        end if;
                
        SET mes_aux = mes_aux + 1;
            
        
        
    
    	
    UNTIL ano_ini > ano_fim END REPEAT;
    

   SELECT * FROM _rp_planilha;
   
    
    
    

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `fin_rp_planilha_recorrentes`(
        IN `_cadeia_id` BIGINT,
        IN `_ano` INTEGER
    )
BEGIN


	DECLARE mes_aux INT;
    
    DECLARE _dia_vencto INT;

    
    
    -- variáveis para insert na temporary table
    DECLARE _titulo VARCHAR(200);
    DECLARE _descricao VARCHAR(200);
    DECLARE _dt_vencto DATE;
    DECLARE _valor_prev DECIMAL(15,2);
    DECLARE _valor_realiz DECIMAL(15,2);
    
    DECLARE dt_ini_aux, dt_fim_aux DATE;
          
    DECLARE _status_aux VARCHAR(50);
    
    
	SELECT descricao, recorr_dia FROM fin_movimentacao WHERE cadeia_id = _cadeia_id LIMIT 1 INTO _titulo, _dia_vencto;
    

    
    -- retornar
    -- titulo	descricao	dt_vencto	valor_prev	valor_realiz
    DROP TEMPORARY TABLE IF EXISTS _rp_planilha;
    CREATE TEMPORARY TABLE IF NOT EXISTS _rp_planilha (      
      titulo VARCHAR(200),
      descricao VARCHAR(200),
      dt_vencto DATE,
      valor_prev DECIMAL(15,2),
      valor_realiz DECIMAL(15,2)
      ) DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci ENGINE=MEMORY;
    
    
    SET mes_aux = 1;
       
     
	-- percorre todos os meses (de janeiro a dezembro)
      
    
    REPEAT
    
    	SET _valor_prev = NULL;
        SET _valor_realiz = NULL;
        SET _status_aux = NULL;
        SET _dt_vencto = NULL;
    
    	block1: begin
        
        	DECLARE CONTINUE HANDLER FOR NOT FOUND BEGIN END;
            
            SELECT 
            	dt_vencto, valor_total, status 
            FROM fin_movimentacao 
            	WHERE
                cadeia_id = _cadeia_id AND 
                dt_vencto >= STR_TO_DATE(CONCAT('1','-',mes_aux,'-',_ano),'%e-%c-%Y') AND
                dt_vencto < LAST_DAY( STR_TO_DATE(CONCAT('1','-',mes_aux,'-',_ano),'%e-%c-%Y') )
                INTO _dt_vencto, _valor_prev, _status_aux;
        
        end;
        
        if ifnull(_dt_vencto, true) then
        	SET _dt_vencto = STR_TO_DATE(CONCAT(_dia_vencto,'-',mes_aux,'-',_ano),'%e-%c-%Y');
        end if;
        
        SET _valor_realiz = null;
               
        if _status_aux = 'REALIZADA' then
            SET _valor_realiz = _valor_prev;
        end if;
            
        SET _descricao = CONCAT(_titulo,' - ',DATE_FORMAT(_dt_vencto,'%m/%Y'));
            
        INSERT INTO _rp_planilha VALUES(_titulo,_descricao,_dt_vencto,_valor_prev,_valor_realiz);
                
		
                
        SET mes_aux = mes_aux + 1;
            
        
        
    
    	
    UNTIL mes_aux = 13 END REPEAT;
    

   SELECT * FROM _rp_planilha;


END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE  PROCEDURE `prod_planilha_corte`(
        IN `loteItensIds` VARCHAR(999),
        IN `tiposInsumosIds` VARCHAR(255)
    )
    READS SQL DATA
BEGIN

    DECLARE p_lote_id BIGINT(20);
	DECLARE p_lote_codigo INT(11);
    DECLARE p_lote_dt_lote DATE;
    DECLARE p_lote_descricao VARCHAR(200);
    DECLARE p_loteitem_id BIGINT(20);
    DECLARE p_confeccao_id BIGINT(20);
    DECLARE p_confeccao_descricao VARCHAR(200);
    DECLARE p_confeccaoitem_id BIGINT(20);
    DECLARE p_tipoinsumo VARCHAR(100);
    DECLARE p_insumo VARCHAR(200);
    DECLARE p_preco_custo DOUBLE;
    
    DECLARE p_qtdelote_02 INT(11) DEFAULT 0;
	DECLARE p_qtdelote_04 INT(11) DEFAULT 0;
	DECLARE p_qtdelote_06 INT(11) DEFAULT 0;
	DECLARE p_qtdelote_08 INT(11) DEFAULT 0;
	DECLARE p_qtdelote_10 INT(11) DEFAULT 0;
	DECLARE p_qtdelote_12 INT(11) DEFAULT 0;
	DECLARE p_qtdelote_14 INT(11) DEFAULT 0;
	DECLARE p_qtdelote_16 INT(11) DEFAULT 0;
	DECLARE p_qtdelote_P INT(11) DEFAULT 0;
	DECLARE p_qtdelote_M INT(11) DEFAULT 0;
	DECLARE p_qtdelote_G INT(11) DEFAULT 0;
	DECLARE p_qtdelote_XG INT(11) DEFAULT 0;
	DECLARE p_qtdelote_SG INT(11) DEFAULT 0;
	DECLARE p_qtdelote_SS INT(11) DEFAULT 0;
    DECLARE p_totallote INT(11) DEFAULT 0;
    
    DECLARE p_qtdeitem_02 DOUBLE DEFAULT 0;
    DECLARE p_qtdeitem_04 DOUBLE DEFAULT 0;
    DECLARE p_qtdeitem_06 DOUBLE DEFAULT 0;
    DECLARE p_qtdeitem_08 DOUBLE DEFAULT 0;
    DECLARE p_qtdeitem_10 DOUBLE DEFAULT 0;
    DECLARE p_qtdeitem_12 DOUBLE DEFAULT 0;
    DECLARE p_qtdeitem_14 DOUBLE DEFAULT 0;
    DECLARE p_qtdeitem_16 DOUBLE DEFAULT 0;
    DECLARE p_qtdeitem_P DOUBLE DEFAULT 0;
    DECLARE p_qtdeitem_M DOUBLE DEFAULT 0;
    DECLARE p_qtdeitem_G DOUBLE DEFAULT 0;
    DECLARE p_qtdeitem_XG DOUBLE DEFAULT 0;
    DECLARE p_qtdeitem_SG DOUBLE DEFAULT 0;
    DECLARE p_qtdeitem_SS DOUBLE DEFAULT 0;
    DECLARE p_totalitem DOUBLE DEFAULT 0;
    
    DECLARE p_qtdetotal_02 DOUBLE DEFAULT 0;
    DECLARE p_qtdetotal_04 DOUBLE DEFAULT 0;
    DECLARE p_qtdetotal_06 DOUBLE DEFAULT 0;
    DECLARE p_qtdetotal_08 DOUBLE DEFAULT 0;
    DECLARE p_qtdetotal_10 DOUBLE DEFAULT 0;
    DECLARE p_qtdetotal_12 DOUBLE DEFAULT 0;
    DECLARE p_qtdetotal_14 DOUBLE DEFAULT 0;
    DECLARE p_qtdetotal_16 DOUBLE DEFAULT 0;
    DECLARE p_qtdetotal_P DOUBLE DEFAULT 0;
    DECLARE p_qtdetotal_M DOUBLE DEFAULT 0;
    DECLARE p_qtdetotal_G DOUBLE DEFAULT 0;
    DECLARE p_qtdetotal_XG DOUBLE DEFAULT 0;
    DECLARE p_qtdetotal_SG DOUBLE DEFAULT 0;
    DECLARE p_qtdetotal_SS DOUBLE DEFAULT 0;
    DECLARE p_totalinsumo DOUBLE DEFAULT 0;

	DECLARE no_more_rows BOOLEAN DEFAULT FALSE;
    DECLARE loop_cntr INT DEFAULT 0;
	DECLARE num_rows INT DEFAULT 0;
    
    

	DECLARE cur_itenslote CURSOR FOR
    	SELECT
          lote.id as lote_id, 
          lote.codigo as lote_codigo,
          lote.dt_lote,
          lote.descricao as lote_descricao,
          loteitem.id as loteitem_id,
          confeccao.id as confeccao_id,
          confeccao.descricao as confeccao_descricao,
          ci.id as confeccaoitem_id,          
          tipoinsumo.descricao as tipoinsumo,
          insumo.descricao as insumo,
          insumopreco.preco_custo,
          sum(liq.`qtde`) as totallote
          from 
              prod_lote_confeccao lote,
              prod_lote_confeccao_item loteitem,
              prod_lote_confeccao_item_qtde liq,
              prod_confeccao confeccao,
              prod_confeccao_item ci,
              prod_insumo insumo, 
              prod_tipo_insumo tipoinsumo,
              prod_insumo_preco insumopreco
          where 
              is_id_in_ids(loteItensIds,loteitem.id) AND
              is_id_in_ids(tiposInsumosIds,tipoinsumo.id) AND
              lote.id = loteitem.lote_confeccao_id AND
              loteitem.confeccao_id = confeccao.id AND
              liq.lote_confeccao_item_id = loteitem.id AND
              confeccao.id = ci.confeccao_id AND
              ci.insumo_id = insumo.id AND
              insumo.tipo_insumo_id = tipoinsumo.id AND
              insumo.id = insumopreco.insumo_id
          GROUP BY insumo.id, confeccao.id
          ORDER BY confeccao_descricao, tipoinsumo.descricao, insumo.descricao;
          
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET no_more_rows = TRUE;
    
    DROP TEMPORARY TABLE IF EXISTS _prod_planilha_corte;
    CREATE TEMPORARY TABLE IF NOT EXISTS _prod_planilha_corte (
      lote_id BIGINT(20),
      lote_codigo INT(11),
      lote_dt_lote DATE,
      lote_descricao VARCHAR(200),
      loteitem_id BIGINT(20),
      confeccao_id BIGINT(20),
      confeccao_descricao VARCHAR(200),
      confeccaoitem_id BIGINT(20),
      tipoinsumo VARCHAR(100),
      insumo VARCHAR(200),
      preco_custo DOUBLE,
      qtdeitem_02 DOUBLE,
      qtdeitem_04 DOUBLE,
      qtdeitem_06 DOUBLE,
      qtdeitem_08 DOUBLE,
      qtdeitem_10 DOUBLE,
      qtdeitem_12 DOUBLE,
      qtdeitem_14 DOUBLE,
      qtdeitem_16 DOUBLE,
      qtdeitem_P  DOUBLE,
      qtdeitem_M  DOUBLE,
      qtdeitem_G  DOUBLE,
      qtdeitem_XG DOUBLE,
      qtdeitem_SG DOUBLE,
      qtdeitem_SS INT(11),
      qtdelote_02 INT(11),
      qtdelote_04 INT(11),
      qtdelote_06 INT(11),
      qtdelote_08 INT(11),
      qtdelote_10 INT(11),
      qtdelote_12 INT(11),
      qtdelote_14 INT(11),
      qtdelote_16 INT(11),
      qtdelote_P  INT(11),
      qtdelote_M  INT(11),
      qtdelote_G  INT(11),
      qtdelote_XG INT(11),
      qtdelote_SG INT(11),
      qtdelote_SS INT(11),      
      qtdetotal_02 DOUBLE,
      qtdetotal_04 DOUBLE,
      qtdetotal_06 DOUBLE,
      qtdetotal_08 DOUBLE,
      qtdetotal_10 DOUBLE,
      qtdetotal_12 DOUBLE,
      qtdetotal_14 DOUBLE,
      qtdetotal_16 DOUBLE,
      qtdetotal_P DOUBLE,
      qtdetotal_M DOUBLE,
      qtdetotal_G DOUBLE,
      qtdetotal_XG DOUBLE,
      qtdetotal_SG DOUBLE,
      qtdetotal_SS DOUBLE,
      totalitem DOUBLE,
      totallote INT(11),
      totalinsumo DOUBLE      
      )DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci ENGINE=MEMORY; 
    
    OPEN cur_itenslote;
    
    select FOUND_ROWS() into num_rows;
    
    

	
	the_loop: 
    LOOP 
      FETCH cur_itenslote INTO
          p_lote_id,
          p_lote_codigo,
          p_lote_dt_lote,
          p_lote_descricao,
          p_loteitem_id,
          p_confeccao_id,
          p_confeccao_descricao,
          p_confeccaoitem_id,
          p_tipoinsumo,
          p_insumo,
          p_preco_custo,
          p_totallote
          ;
          
        IF no_more_rows THEN
            CLOSE cur_itenslote;
            LEAVE the_loop;
        END IF;
      
      
      
      
      BLOCK2: begin
      
        DECLARE CONTINUE HANDLER FOR NOT FOUND BEGIN END;
        
        CALL `prod_planilha_corte_totais_grade`(p_confeccaoitem_id, p_loteitem_id, 3, '02', p_qtdelote_02, p_qtdetotal_02, p_qtdeitem_02);
        CALL `prod_planilha_corte_totais_grade`(p_confeccaoitem_id, p_loteitem_id, 3, '04', p_qtdelote_04, p_qtdetotal_04, p_qtdeitem_04);
        CALL `prod_planilha_corte_totais_grade`(p_confeccaoitem_id, p_loteitem_id, 3, '06', p_qtdelote_06, p_qtdetotal_06, p_qtdeitem_06);
        CALL `prod_planilha_corte_totais_grade`(p_confeccaoitem_id, p_loteitem_id, 3, '08', p_qtdelote_08, p_qtdetotal_08, p_qtdeitem_08);
        CALL `prod_planilha_corte_totais_grade`(p_confeccaoitem_id, p_loteitem_id, 3, '10', p_qtdelote_10, p_qtdetotal_10, p_qtdeitem_10);
        CALL `prod_planilha_corte_totais_grade`(p_confeccaoitem_id, p_loteitem_id, 3, '12', p_qtdelote_12, p_qtdetotal_12, p_qtdeitem_12);
        CALL `prod_planilha_corte_totais_grade`(p_confeccaoitem_id, p_loteitem_id, 3, '14', p_qtdelote_14, p_qtdetotal_14, p_qtdeitem_14);
        CALL `prod_planilha_corte_totais_grade`(p_confeccaoitem_id, p_loteitem_id, 3, '16', p_qtdelote_16, p_qtdetotal_16, p_qtdeitem_16);
        
        CALL `prod_planilha_corte_totais_grade`(p_confeccaoitem_id, p_loteitem_id, 1, 'P', p_qtdelote_p, p_qtdetotal_p, p_qtdeitem_p);
        CALL `prod_planilha_corte_totais_grade`(p_confeccaoitem_id, p_loteitem_id, 1, 'M', p_qtdelote_m, p_qtdetotal_m, p_qtdeitem_m);
        CALL `prod_planilha_corte_totais_grade`(p_confeccaoitem_id, p_loteitem_id, 1, 'G', p_qtdelote_g, p_qtdetotal_g, p_qtdeitem_g);
        CALL `prod_planilha_corte_totais_grade`(p_confeccaoitem_id, p_loteitem_id, 1, 'XG', p_qtdelote_xg, p_qtdetotal_xg, p_qtdeitem_xg);
        CALL `prod_planilha_corte_totais_grade`(p_confeccaoitem_id, p_loteitem_id, 1, 'SG', p_qtdelote_sg, p_qtdetotal_sg, p_qtdeitem_sg);
        CALL `prod_planilha_corte_totais_grade`(p_confeccaoitem_id, p_loteitem_id, 1, 'SS', p_qtdelote_ss, p_qtdetotal_ss, p_qtdeitem_ss);
      
      end;
      
      BLOCK3: begin
      
        DECLARE CONTINUE HANDLER FOR NOT FOUND BEGIN END;
        
          SELECT
            sum(ciq.qtde) as totalitem, 
          	sum((lciq.qtde * ciq.qtde)) as qtde INTO p_totalitem, p_totalinsumo  
          FROM 
            prod_lote_confeccao_item_qtde lciq, 
            prod_confeccao_item_qtde ciq
          WHERE 
            lciq.grade_tamanho_id = ciq.grade_tamanho_id AND 
            lciq.lote_confeccao_item_id = p_loteitem_id AND 
            ciq.confeccao_item_id = p_confeccaoitem_id;
        
      
      end;
    
        
      INSERT INTO _prod_planilha_corte
      	( lote_id,
          lote_codigo,
          lote_dt_lote,
          lote_descricao,
          loteitem_id,
          confeccao_id,
          confeccao_descricao,
          confeccaoitem_id,
          tipoinsumo,
          insumo,
          preco_custo,
          qtdeitem_02,
          qtdeitem_04,
          qtdeitem_06,
          qtdeitem_08,
          qtdeitem_10,
          qtdeitem_12,
          qtdeitem_14,
          qtdeitem_16,
          qtdeitem_P ,
          qtdeitem_M ,
          qtdeitem_G ,
          qtdeitem_XG,
          qtdeitem_SG,
          qtdeitem_SS,
          qtdelote_02,
          qtdelote_04,
          qtdelote_06,
          qtdelote_08,
          qtdelote_10,
          qtdelote_12,
          qtdelote_14,
          qtdelote_16,
          qtdelote_P,
          qtdelote_M,
          qtdelote_G,
          qtdelote_XG,
          qtdelote_SG,
          qtdelote_SS,
          qtdetotal_02,
          qtdetotal_04,
          qtdetotal_06,
          qtdetotal_08,
          qtdetotal_10,
          qtdetotal_12,
          qtdetotal_14,
          qtdetotal_16,
          qtdetotal_P,
          qtdetotal_M,
          qtdetotal_G,
          qtdetotal_XG,
          qtdetotal_SG,
          qtdetotal_SS,
          totalitem,
          totallote,
          totalinsumo)
      	VALUES
        	(p_lote_id,
                p_lote_codigo,
                p_lote_dt_lote,
                p_lote_descricao,
                p_loteitem_id,
                p_confeccao_id,
                p_confeccao_descricao,
                p_confeccaoitem_id,
                p_tipoinsumo,
                p_insumo,
                p_preco_custo,
                p_qtdeitem_02,
                p_qtdeitem_04,
                p_qtdeitem_06,
                p_qtdeitem_08,
                p_qtdeitem_10,
                p_qtdeitem_12,
                p_qtdeitem_14,
                p_qtdeitem_16,
                p_qtdeitem_p,
                p_qtdeitem_m,
                p_qtdeitem_g,
                p_qtdeitem_xg,
                p_qtdeitem_sg,
                p_qtdeitem_ss,
                p_qtdelote_02,
                p_qtdelote_04,
                p_qtdelote_06,
                p_qtdelote_08,
                p_qtdelote_10,
                p_qtdelote_12,
                p_qtdelote_14,
                p_qtdelote_16,
                p_qtdelote_p,
                p_qtdelote_m,
                p_qtdelote_g,
                p_qtdelote_xg,
                p_qtdelote_sg,
                p_qtdelote_ss,
                p_qtdetotal_02,
                p_qtdetotal_04,
                p_qtdetotal_06,
                p_qtdetotal_08,
                p_qtdetotal_10,
                p_qtdetotal_12,
                p_qtdetotal_14,
                p_qtdetotal_16,
                p_qtdetotal_p,
                p_qtdetotal_m,
                p_qtdetotal_g,
                p_qtdetotal_xg,
                p_qtdetotal_sg,
                p_qtdetotal_ss,
                p_totalitem,
                p_totallote,
                p_totalinsumo
                );  
      

      
      SET loop_cntr = loop_cntr + 1;

	END LOOP the_loop;
    
    SELECT * FROM _prod_planilha_corte ORDER BY p_confeccao_descricao, p_tipoinsumo, p_insumo;


END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE  PROCEDURE `prod_planilha_corte_totais_grade`(
        IN `p_confeccaoitem_id` BIGINT(20),
        IN `p_loteitem_id` BIGINT(20),
        IN `gradecodigo` BIGINT(20),
        IN `tamanho` VARCHAR(100),
        OUT `qtdelote` INTEGER(11),
        OUT `qtdetotal` DOUBLE,
        OUT `qtdeitem` DOUBLE
    )
BEGIN
	
      SELECT 
      	lciq.qtde,
        ciq.qtde as qtdeitem,
        (lciq.qtde * ciq.qtde) as qtde 
        INTO qtdelote, qtdeitem, qtdetotal 
      FROM 
      	prod_lote_confeccao_item_qtde lciq, 
        prod_confeccao_item_qtde ciq, 
        est_grade grade, 
        est_grade_tamanho gradetamanho 
      WHERE 
      	lciq.grade_tamanho_id = ciq.grade_tamanho_id AND 
        lciq.grade_tamanho_id = gradetamanho.id AND 
        gradetamanho.grade_id = grade.id AND 
        lciq.lote_confeccao_item_id = p_loteitem_id AND 
        ciq.confeccao_item_id = p_confeccaoitem_id AND 
        gradetamanho.tamanho = tamanho AND grade.codigo = gradecodigo;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE  PROCEDURE `split_ids`(
        IN `strIDs` VARCHAR(255)
    )
BEGIN

  DECLARE strLen    INT DEFAULT 0;
  DECLARE subStrLen INT DEFAULT 0;
  DECLARE subs		VARCHAR(255);

  IF strIDs IS NULL THEN
    SET strIDs = '';
  END IF;
  
  DROP TEMPORARY TABLE IF EXISTS _ids;
  CREATE TEMPORARY TABLE IF NOT EXISTS _ids (
  	_id BIGINT(20)
  ) DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci ENGINE=MEMORY;

  do_this:
    LOOP
      SET strLen = LENGTH(strIDs);
      
      
      
      SET subs = SUBSTRING_INDEX(strIDs, ',', 1);
      
      INSERT INTO _ids VALUES(CAST(subs AS UNSIGNED));
      
      SET subStrLen = LENGTH(SUBSTRING_INDEX(strIDs, ',', 1));
      SET strIDs = MID(strIDs, subStrLen+2, strLen);
      
      
      
      IF strIDs = NULL or trim(strIds) = '' THEN
        LEAVE do_this;
      END IF;
      
  END LOOP do_this;
  
  select * from _ids;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-06-10 11:50:25
